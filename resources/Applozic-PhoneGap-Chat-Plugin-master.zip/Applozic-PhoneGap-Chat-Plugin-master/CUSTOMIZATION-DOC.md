You can modify mck-sidebox-1.0.css class located at:
  
https://github.com/AppLozic/Applozic-PhoneGap-Chat-Plugin/blob/master/www/applozic/css/app/mck-sidebox-1.0.css

JS and CSS code is present under 
https://github.com/AppLozic/Applozic-PhoneGap-Chat-Plugin/tree/master/www/applozic

You can modify the source code based on your design requirements.
